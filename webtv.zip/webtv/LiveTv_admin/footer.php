<link href="../css/style.css" rel="stylesheet" type="text/css">
&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2" align="center" class="footer">Copyright 2016. All rights reserved. <a href="https://codecanyon.net/user/creativeinfoway26">creativeinfoway26</a>
</td>
    </tr>
</table>
</div>
</body>
</html>
