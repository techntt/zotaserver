<?php
include("header.php");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td class="welcome_text_msg">Welcome to Control panel</td>
	</tr>
</table>
<?php
    include("footer.php");
?>
