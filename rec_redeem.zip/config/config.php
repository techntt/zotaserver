<?php

//database configuration
	
	$host       = "localhost";
	$user       = "000";
	$pass       = "000";
	$database   = "000";

// Admin Details

$display_name  = "yash Dev";
$image_url = "images/img.jpg";

//$image_url = "http://example.com/images/img.jpg";

$Google_Play_Link = "https://play.google.com/store/apps/details?id=com.droidoxy.pocket";
	

// modify below

$APP_NAME = "POCKET";

$APP_TITLE = "POCKET - Android Rewards App";

//edit to your domain example:yourdomain.com
$APP_HOST = "pocket.droid.oxywebs.in"; 

//edit to your domain url
$Server_URL = "http://pocket.droid.oxywebs.in";

$Company_URL = "http://droid.oxywebs.in";


// SMTP Settings | For password recovery

//SMTP auth (Enable SMTP authentication)
$SMTP_AUTH = true;

//SMTP secure (Enable TLS encryption, `ssl` also accepted)
$SMTP_SECURE = 'tls';

//SMTP port (TCP port to connect to)
$SMTP_PORT = 587;

//SMTP from email to show on recipient Email
$SMTP_EMAIL = 'info@pocket.com';

//SMTP username to Authentiacte
$SMTP_USERNAME = 'your-gmail@gmail.com';

//SMTP password
$SMTP_PASSWORD = 'your-password';


?>