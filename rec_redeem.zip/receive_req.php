<?php

echo "404 - Not Found";

?>