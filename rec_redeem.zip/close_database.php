<?php

	include(config/config.php'); 

// Closing database connection
	$connect->close();
?>