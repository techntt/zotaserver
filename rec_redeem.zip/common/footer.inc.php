<?php

    /*!
	 * POCKET v1.1
	 *
	 * http://droid.oxywebs.in
	 * droid@oxywebs.com, yash@oxywebs.com
	 *
	 * Copyright 2016 yashDev (http://yash.oxywebs.in/)
 */

?>

    <div id="page_footer">

        <div id="footer" class="clear">
            <?php echo APP_TITLE; ?> © <?php echo APP_YEAR; ?>
            <div>
                <a target="_blank" href="<?php echo COMPANY_URL; ?>"><?php echo APP_VENDOR; ?></a>
            </div>
        </div>

    </div>

    <script type="text/javascript" src="/js/jquery-2.1.1.js"></script>