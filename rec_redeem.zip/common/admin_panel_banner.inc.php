<?php

    /*!
	 * POCKET v1.1
	 *
	 * http://droid.oxywebs.in
	 * droid@oxywebs.com, yash@oxywebs.com
	 *
	 * Copyright 2016 yashDev (http://yash.oxywebs.in/)
 */

?>

<?php

    if (APP_DEMO) {

        ?>

            <div id="page_body" class="banner">
                <div id="wrap3">
                    <div id="wrap2">
                        <div id="wrap1">
                            <div id="content">
                                <div class="note orange">
                                    <div class="title">Warning!</div>
                                    Enabled demo version mode! The changes you've made will not be saved.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php
    }
?>